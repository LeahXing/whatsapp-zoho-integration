"""Historical Deal backfill. Dry-run first; writes only missing Deal Notes jobs."""
from datetime import datetime, timezone
from app.repositories.deal_backfill_repository import get_deal_for_backfill, find_group_messages_for_backfill
from app.storage.processing_state import enqueue_note


def _utc(value):
    if value is None or value == '':
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        if number > 1e11:
            number /= 1000
        return datetime.fromtimestamp(number, tz=timezone.utc)
    if isinstance(value, str):
        return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(timezone.utc)
    raise ValueError('Invalid datetime')


def preview_or_backfill(deal_id: str, dry_run: bool = True):
    deal = get_deal_for_backfill(deal_id)
    group_id = str(deal.get('WhatsApp_Group_ID') or '').strip()
    start = _utc(deal.get('WhatsApp_Conversation_Start'))
    end = _utc(deal.get('WhatsApp_Conversation_End'))
    if not group_id or start is None:
        raise ValueError('Deal requires WhatsApp_Group_ID and WhatsApp_Conversation_Start')
    if end is not None and end < start:
        raise ValueError('Conversation End precedes Start')
    if not deal.get('Contact_Name'):
        raise ValueError('Deal must be associated with a Contact')
    # Backfill is allowed for closed Deals, using the recorded conversation window.
    candidates = []
    skipped = {'missing_timestamp': 0, 'missing_message_id': 0, 'conflicting_deal': 0}
    for message in find_group_messages_for_backfill(group_id):
        mid = message.get('Message_ID')
        if not mid:
            skipped['missing_message_id'] += 1
            continue
        try:
            when = _utc(message.get('Unix_Timestamp'))
        except (ValueError, TypeError, OverflowError):
            when = None
        if when is None:
            skipped['missing_timestamp'] += 1
            continue
        if when < start or (end is not None and when > end):
            continue
        linked = message.get('Deal')
        linked_id = str(linked.get('id')) if isinstance(linked, dict) and linked.get('id') else None
        if linked_id and linked_id != str(deal_id):
            skipped['conflicting_deal'] += 1
            continue
        candidates.append((when, str(mid), message))
    candidates.sort(key=lambda x: (x[0], x[1]))
    preview = [{'message_id': mid, 'timestamp_utc': when.isoformat(),
                'sender': m.get('Sender_Name'), 'message': m.get('Message')}
               for when, mid, m in candidates]
    response = {'deal_id': deal_id, 'deal_name': deal.get('Deal_Name'), 'group_id': group_id,
                'dry_run': dry_run, 'matched_count': len(preview), 'skipped': skipped,
                'messages': preview}
    if dry_run:
        return response
    queued = []
    for when, mid, m in candidates:
        result = enqueue_note(
            message_id=mid, module_name='Deals', record_id=deal_id, group_id=group_id,
            sender_name=m.get('Sender_Name') or 'Unknown',
            group_name=m.get('Group_Name') or 'Unknown Group',
            message_text=m.get('Message') or '', unix_timestamp=when.timestamp(),
            display_timestamp=when.strftime('%Y-%m-%d %H:%M:%S UTC'),
        )
        queued.append({'message_id': mid, **result})
    response['jobs'] = queued
    return response
